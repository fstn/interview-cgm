#!/bin/sh

echo "Starting capture frontend"

nginx -g 'daemon off;'