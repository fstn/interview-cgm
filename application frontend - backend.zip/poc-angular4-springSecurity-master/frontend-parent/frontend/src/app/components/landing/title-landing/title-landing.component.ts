import {Component, OnInit} from "@angular/core";

/**
 * Landing page title
 */
@Component({
  selector: 'app-title-landing',
  templateUrl: './title-landing.component.html',
  styleUrls: ['./title-landing.component.css']
})
export class TitleLandingComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
