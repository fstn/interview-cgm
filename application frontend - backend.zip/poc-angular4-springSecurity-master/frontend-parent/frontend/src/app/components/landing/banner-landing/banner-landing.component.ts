import {Component, OnInit} from "@angular/core";

/**
 * Banner part of landing page
 */
@Component({
  selector: 'app-banner-landing',
  templateUrl: './banner-landing.component.html',
  styleUrls: ['./banner-landing.component.css']
})
export class BannerLandingComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
