import {Component, OnInit} from "@angular/core";

/**
 * Text part of landing page
 */
@Component({
  selector: 'app-text-landing',
  templateUrl: './text-landing.component.html',
  styleUrls: ['./text-landing.component.css']
})
export class TextLandingComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
