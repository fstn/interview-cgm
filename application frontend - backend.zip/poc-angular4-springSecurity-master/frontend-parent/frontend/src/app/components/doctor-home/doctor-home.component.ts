import {Component, OnInit} from "@angular/core";

@Component({
  moduleId: module.id,
  templateUrl: 'doctor-home.component.html'
})

export class DoctorComponent implements OnInit {
  constructor() {
  }

  ngOnInit(): void {
  }

}
